"use strict";
const loc_aPosition = 3;
const loc_aColor = 7;
const SRC_VERT = 
`#version 300 es
layout(location=${loc_aPosition}) in vec4 aPosition;
layout(location=${loc_aColor}) in vec4 aColor;
out vec4 vColor;
uniform mat4 uMVP;
void main()
{
    gl_Position = uMVP*aPosition;
    vColor = aColor;
}`;
const SRC_FRAG =
`#version 300 es
precision mediump float;
in vec4 vColor;
out vec4 fColor;
void main()
{
    fColor = vColor;
}`;

function main()
{
    const canvas = document.getElementById('webgl');
    const gl = canvas.getContext("webgl2");

    initShaders(gl, SRC_VERT, SRC_FRAG);

    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    const {vao,n} = init_vbo(gl);
    
    let w = canvas.width;
    let h = canvas.height;
    
    const loc_MVP = gl.getUniformLocation(gl.program, 'uMVP');
    let MVP = new Matrix4();
    
    gl.clear(gl.COLOR_BUFFER_BIT);
    
    gl.viewport(0, 0, w/2, h);
    MVP.setOrtho(-1,1,-1,1,0,2);
    MVP.lookAt(1,.1,1, 0,0,0, 0,1,0);
    gl.uniformMatrix4fv(loc_MVP, false, MVP.elements);
    gl.bindVertexArray(vao);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, n);
    gl.bindVertexArray(null);
    
    gl.viewport(w/2, 0, w/2, h);
    MVP.setOrtho(-1,1,-1,1,0,2);
    MVP.lookAt(1,.3,-1, 0,0,0, 0,1,0);
    gl.uniformMatrix4fv(loc_MVP, false, MVP.elements);
    gl.bindVertexArray(vao);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, n);
    gl.bindVertexArray(null);

}

function init_vbo(gl, n)
{
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);

    const attribs = new Float32Array([
        -.5, -.5, 0, 1, 0, 0,
         .5, -.5, 0, 0, 1, 0,
         .5,  .5, 0, 0, 0, 1,
        -.5,  .5, 0, 1, 1, 1,
        ]);

    const vbo = gl.createBuffer();
    
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, attribs, gl.STATIC_DRAW);
    
    const FSIZE = attribs.BYTES_PER_ELEMENT;

    gl.vertexAttribPointer(loc_aPosition, 3, gl.FLOAT, false, FSIZE*6, 0);
    gl.enableVertexAttribArray(loc_aPosition);
    
    gl.vertexAttribPointer(loc_aColor, 3, gl.FLOAT, false, FSIZE*6, FSIZE*3);
    gl.enableVertexAttribArray(loc_aColor);

    gl.bindVertexArray(null);
    gl.bindBuffer(gl.ARRAY_BUFFER, null);

    return {vao,n:4};
}
